<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div style="width: 70%;">
        <h3>Ista kartica, dodatna online sigurnost.</h3> 
        <p>
            Verified by Visa je nova uslugu koja Vam omogućava online kupovinu uz dodatnu sigurnost.
            Jednostavnim postupkom Verified by Visa Vaš identitet se potvrđuje prilikom kupovine u online
            trgovinama uključenima u program. Ovaj pogodan način kupovine moguć je putem Vaše postojeće Visa
            kartice. <br><br>
            Osim toga, Verified by Visa je brz postupak. Potrebno je samo jednom registrovati svoju karticu i kreirati
            password. Potom, nakon obavljene kupovine u trgovinama uključenima u program, pojavit će se Verified
            by Visa prozor. Jednostavno unesite svoj password i kliknite na "submit". Vaš je identitet potvrđen, a
            kupovina sigurna. <br> <br>
            Kako biste aktivirali Verified by Visa na svojoj Visa kartici ili saznali više o ovome, kontaktirajte svoju
            financijsku ustanovu koja Vam je izdala Vašu Visa karticu.
            Za detaljne informacije o Verified by Visa programu kliknite na <a href="https://www.visa.co.uk/about-visa/visa-in-europe.html" target="_blank" > www.visaeu.com</a>. 
        </p>
    
    </div>
   
</body>
</html>