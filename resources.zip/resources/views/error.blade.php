@extends('layouts.master')

@section('content')
@include('layouts.error')
<h1>Ups, something went wrong!</h1>
@endsection