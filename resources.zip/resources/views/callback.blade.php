@extends('layouts.master')

@section('content')
@include('layouts.error')
<h1>Callback page</h1>
@endsection