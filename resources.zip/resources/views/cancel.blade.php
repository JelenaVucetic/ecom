@extends('layouts.master')

@section('content')
@include('layouts.error')
<h1>Cancel page</h1>
@endsection