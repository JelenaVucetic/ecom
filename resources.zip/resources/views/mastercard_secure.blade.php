<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div style="width: 70%">
        <p>MasterCard® SecureCode™ je nova usluga MasterCard-a i Banke izdavaoca vaše kartice koja Vam
            pruža dodatnu sigurnost prilikom online kupovine. Za korištenje ove usluge nije Vam potrebna nova
            MasterCard ili Maestro® kartica. Vi birate svoj osobni MasterCard SecureCode i nikada ga ne dijelite s
            bilo kojim internet trgovcem. Privatni kod znači dodatnu sigurnost protiv neautorizirane upotrebe Vaše
            kreditne ili debitne kartice kada kupujete online. <br> <br>
            Prilikom online plaćanje MasterCard ili Maestro karticom, otvara se prozor Banke izdavaoca Vaše
            kartice i traži se da unesete Vas licni SecureCode, jednako kao što vamtraži da unesete PIN na
            bankomatu. U samo nekoliko sekundi izdavatelj kartice potvrđuje Vaše podatke i omogućava Vam da
            završite svoju online kupovinu. <br> <br>
            Za detaljnije informacije o MasterCard SecureCode programu kliknite
            na <a href="https://www.mastercard.us/en-us.html" target="_blank"> www.mastercardsecurecode.com</a>.
            </p>
    </div>
</body>
</html>