<!DOCTYPE html>
<html>
<head>
    <title>UrbanOne</title>
</head>
<body>
    <p>{{ $details['description'] }}</p>
</body>
</html>