
<div class="about-urban cart-about">
    <div class="about-urban-box cart-about-box">
        <div class="about-urban-info">
            <img src="/site-images/12 High qualitys - ikonica.svg" alt="">
            <div>
                <h6>High quality</h6>
                <p>Available as Standard or <br> Express delivery</p>
            </div>
            <a class="learn-more" href="/about#quality">Learn more</a>
            <a class="learn-more-img" href="/about#quality" style="display:none;"><img src="/site-images/about-right-arrow.png" alt=""></a>
        </div>
        <div class="about-urban-info">
            <img src="/site-images/12 Secure Payment.svg" alt="">
            <div>
                <h6>Secure Payments</h6>
                <p>100% Secure payments for <br> all your orders</p>
            </div>
            <a class="learn-more" href="/help_center">Learn more</a>
            <a class="learn-more-img" href="/help_center" style="display:none;"><img src="/site-images/about-right-arrow.png" alt=""></a>
        </div>
        <div class="about-urban-info">
            <img src="/site-images/12 Free Return - Ikonica.svg" alt="">
            <div>
                <h6>Free Return</h6>
                <p>Exchange or money back <br> guarantee for all orders</p>
            </div>
            <a class="learn-more" href="/help_center">Learn more</a>
            <a class="learn-more-img" href="/help_center" style="display:none;"><img src="/site-images/about-right-arrow.png" alt=""></a>
        </div>
        <div class="about-urban-info">
            <img src="/site-images/12 Local Chat support.svg" alt="">
            <div>
                <h6>Local Support</h6>
                <p>24/7 Dedicated support</p>
            </div>
            <a class="learn-more" href="http://ecom.example/contact_us">Learn more</a>
            <a class="learn-more-img" href="http://ecom.example/contact_us" style="display:none;"><img src="/site-images/about-right-arrow.png" alt=""></a>
        </div>
    </div>
</div>